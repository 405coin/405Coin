/*
 * Copyright (c) 2020 The 405Coin developer
 * Distributed under the MIT software license, see the accompanying
 * file COPYING or http://www.opensource.org/licenses/mit-license.php.
 * 
 * FounderPayment.h
 *
 *  Created on: Jun 24, 2018
 *      Author: Tri Nguyen
 */

#ifndef SRC_FOUNDER_PAYMENT_H_
#define SRC_FOUNDER_PAYMENT_H_

#include <string>
#include <amount.h>
#include <primitives/transaction.h>
#include <script/standard.h>
#include <limits.h>
//using namespace std;

static const std::string DEFAULT_FOUNDER_ADDRESS = "4o5epMWh6aQRYJ8EtHDg7ThcRbZKPGdYZ4XS";
struct FounderRewardStructure {
    int blockHeight;
    int rewardPercentage;
};

class FounderPayment {
public:
    FounderPayment(std::vector <FounderRewardStructure> rewardStructures = {}, int startBlock = 0,
                   const std::string &address = DEFAULT_FOUNDER_ADDRESS) {
        this->founderAddress = address;
        this->startBlock = startBlock;
        this->rewardStructures = rewardStructures;
    }

    ~FounderPayment() {};

    CAmount getFounderPaymentAmount(int blockHeight, CAmount blockReward);

    void FillFounderPayment(CMutableTransaction &txNew, int nBlockHeight, CAmount blockReward, CTxOut &txoutFounderRet);

    bool IsBlockPayeeValid(const CTransaction &txNew, const int height, const CAmount blockReward);

    int getStartBlock() { return this->startBlock; }

private:
    std::string founderAddress;
    int startBlock;
    std::vector <FounderRewardStructure> rewardStructures;
};


#endif /* SRC_FOUNDER_PAYMENT_H_ */
