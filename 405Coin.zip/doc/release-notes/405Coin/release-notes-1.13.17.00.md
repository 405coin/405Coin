405Coin Core version 1.13.17.00
==========================

Release is now available from:

<https://405.mn/latest>

This is a new major version release, bringing new features, various bugfixes
and other improvements.

This release is mandatory for all nodes.

Please report bugs using the issue tracker at github:

<https://github.com/405coin/405сoin/issues>


Upgrading and downgrading
=========================

How to Upgrade
--------------
TODO
