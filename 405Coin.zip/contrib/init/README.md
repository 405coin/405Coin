Sample configuration files for:
```
SystemD: 405Coind.service
Upstart: 405Coind.conf
OpenRC:  405Coind.openrc
         405Coind.openrcconf
CentOS:  405Coind.init
OS X:    org.405Coin.405Coind.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
